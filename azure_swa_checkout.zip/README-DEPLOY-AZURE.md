
# Deploy público (Azure Static Web Apps)

Estructura:
- `/static` → tu checkout (index.html, styles.css, app.js, ...)
- `/api/start-payment` → Function que reenvía al backend real (`BACKEND_URL`)
- `staticwebapp.config.json` → enrutado simple a `/static/index.html`

## Pasos (sin instalar nada en local)
1. **Sube esta carpeta a un repo GitHub**.
2. En **Azure Portal** → **Static Web Apps** → **Create**:
   - *Deployment type*: **GitHub**
   - *App location*: `static`
   - *API location*: `api`
   - *Build presets*: **Custom**
3. Una vez creada, ve a **Configuration** de la SWA y añade:
   - `BACKEND_URL` = `https://api.mi-dominio.com` (sin `/api/start-payment`).
4. Espera a que finalice el **GitHub Action** de despliegue.
5. Abre la URL `https://<tu-app>.azurestaticapps.net` → **/static/index.html**.

## Notas
- La Function expone `POST /api/start-payment` y reenvía al backend real.
- Si tu backend exige allowlist de origen, añade el dominio `*.azurestaticapps.net`.
